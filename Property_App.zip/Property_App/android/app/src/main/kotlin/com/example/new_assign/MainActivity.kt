package com.example.new_assign

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
